import QuizForm from "@/components/QuizForm";
import React from "react";

const Step5 = ({ setIsResult }) => {
  return (
    <>
      <QuizForm setIsResult={setIsResult} />
    </>
  );
};

export default Step5;
