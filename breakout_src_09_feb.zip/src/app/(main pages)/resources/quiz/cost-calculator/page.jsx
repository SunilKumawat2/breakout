import React from "react";
import CostCalculator from "@/components/Quizes/CostQuiz/CostQuiz";

const page = () => {
  return <CostCalculator />;
};

export default page;
