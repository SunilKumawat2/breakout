import React from "react";
import FindingPartyQuiz from "@/components/Quizes/FindingPartyQuiz/FindingPartyQuiz";

const page = () => {
  return <FindingPartyQuiz />;
};

export default page;
